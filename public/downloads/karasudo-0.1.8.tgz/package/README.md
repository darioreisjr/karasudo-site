<p align="center">
  <img src="client/public/assets/brand/logo-mark@4x.png" width="96" alt="Logo do Karasudo: prédio em pixel art com um corvo pousado no telhado" />
</p>

<h1 align="center">Karasudo</h1>

<p align="center">
  <b>O escritório em pixel art dos seus agentes de IA.</b><br />
  Claude Code, Codex, Gemini CLI e Antigravity no mesmo prédio: cada projeto vira uma sala, cada agente vira um
  personagem que mostra, em tempo real, o que está fazendo.
</p>

<p align="center">
  <img src="docs/assets/escritorio.png" alt="O escritório do Karasudo em pixel art com agentes trabalhando, balões de atividade e notificações ao vivo" />
</p>

---

O nome vem de _karasu_ (烏, corvo) e _dō_ (堂, casa). Como os corvos que levam as notícias, o Karasudo traz para uma
tela só o que cada agente está fazendo: quem está digitando, quem rodou um comando, quem **levantou a mão porque
precisa de você** e quem terminou e foi tomar um café.

Tudo roda no seu computador. O Karasudo só **lê** os arquivos que as próprias ferramentas gravam (e, se você quiser,
recebe avisos dos hooks delas): nada é enviado para fora.

## Sumário

- [O que ele mostra](#o-que-ele-mostra)
- [Ferramentas suportadas](#ferramentas-suportadas)
- [Instalação](#instalação)
- [Conectar cada ferramenta](#conectar-cada-ferramenta)
- [Como usar](#como-usar)
- [Configuração](#configuração)
- [Desenvolvimento](#desenvolvimento)
- [Problemas comuns](#problemas-comuns)
- [Créditos e licença](#créditos-e-licença)

## O que ele mostra

- **Um prédio, uma sala por projeto.** Agentes de ferramentas diferentes no mesmo projeto ficam na mesma sala.
- **Um personagem por sessão**, com o que está fazendo agora num balão: "Editando login.ts", "Rodando os testes",
  "Pesquisando na web"...
- **Status de relance:**

  | Personagem          | Quer dizer                                      |
  | ------------------- | ----------------------------------------------- |
  | Digitando na mesa   | trabalhando num pedido seu                      |
  | Mão levantada       | precisa de você (uma aprovação ou uma pergunta) |
  | De olho no terminal | esperando um comando que roda em segundo plano  |
  | Passeando, no café  | terminou e espera a próxima instrução           |
  | Indo embora         | a sessão foi encerrada                          |

- **Detalhes de cada agente** (clique no personagem): atividade, tarefas, subagentes, linha do tempo, tokens, modelo e
  branch.
- **Terminal** (tecla `T`): a conversa da sessão, como no terminal da ferramenta, ao vivo.
- **Meu dia** (tecla `M`): para onde foi o tempo do dia, por projeto e por conta.
- **Responder pelo escritório** (tecla `P`) e **mandar mensagens** aos agentes, no Claude Code e no Codex.
- Ciclo de dia e noite, temas, sons e notificações do navegador.
- **Modo aplicativo (PWA):** instale no celular ou computador para rodar em tela cheia com acesso instantâneo.

## Ferramentas suportadas

| Ferramenta            | Como aparece         | Ao vivo                                 | Responder e mandar mensagens    |
| --------------------- | -------------------- | --------------------------------------- | ------------------------------- |
| **Claude Code**       | sem selo             | com o mod (`npm run mod:install`)       | sim, com o mod                  |
| **Codex** (CLI e app) | selo **CODEX**       | com os hooks (`npm run codex:install`)  | sim                             |
| **Gemini CLI**        | selo **GEMINI**      | com os hooks (`npm run gemini:install`) | ainda não                       |
| **Antigravity**       | selo **ANTIGRAVITY** | sim, sem instalar nada                  | ainda não (o app não tem hooks) |

Sem o mod ou os hooks, o Karasudo ainda mostra as sessões, só que com atraso (pelo que cada ferramenta grava em
arquivo).

## Instalação

### Requisitos

- **Node.js 22.12 ou mais novo** (`node --version`).
- **Git**.
- Windows, macOS ou Linux.

### Baixar e subir

```bash
git clone https://github.com/darioreisjr/karasudo.git
cd karasudo
npm install
npm run dev
```

Abra **http://localhost:4747**. O Karasudo acha sozinho as pastas das ferramentas (`~/.claude`, `~/.codex`,
`~/.gemini` e `~/.gemini/antigravity`) e mostra as sessões abertas.

Para usar outra porta, defina `KARASUDO_PORT` antes de subir (no Windows, uma vez só, no PowerShell):

```powershell
[Environment]::SetEnvironmentVariable('KARASUDO_PORT', '1818', 'User')
```

Feche e abra o terminal e rode `npm run dev` de novo: o endereço passa a ser http://localhost:1818.

### Versão de produção

```bash
npm run build
npm start
```

### Rodar no Docker local

Se preferir rodar isolado em container na sua própria máquina (montando as pastas dos agentes como somente-leitura):

```bash
npm run docker:up     # sobe o container Karasudo localmente
npm run docker:logs   # acompanha os logs do container
npm run docker:down   # encerra o container
```

O container preserva os dados locais em um volume nomeado e expõe a porta `4747` para o seu navegador. Detalhes de memória (cgroups) e integridade dos volumes podem ser visualizados diretamente no modal de Diagnóstico da interface.

## Conectar cada ferramenta

Rode os comandos dentro da pasta do Karasudo. Cada um faz backup do arquivo que altera e mantém os seus outros hooks.

### Claude Code

```bash
npm run mod:install     # o mod do Karasudo e os plugins de permissões e de mensagens, em cada conta
npm run mod:status      # confere
```

Precisa do Claude Code 2.1.287 ou mais novo. Nas sessões que já estavam abertas, rode `/reload-plugins`.

> **Windows:** se o comando disser que não achou o `claude`, passe o caminho do executável:
> `npm run mod:install -- --claude "%APPDATA%\npm\node_modules\@anthropic-ai\claude-code\bin\claude.exe"`

### Codex

```bash
npm run codex:install
npm run codex:status
```

Depois, abra o Codex, digite `/hooks` e **aprove os hooks do Karasudo**: o Codex só roda um hook novo depois que você o
aprova.

### Gemini CLI

```bash
npm run gemini:install
npm run gemini:status
```

As sessões do Gemini CLI que já estavam abertas passam a usar os hooks depois que você sai e abre de novo. O Gemini CLI
precisa estar logado: rode `gemini` no terminal e escolha **Login with Google**.

### Antigravity

Não precisa instalar nada. O Karasudo lê as conversas que o Antigravity grava em `~/.gemini/antigravity` a cada passo.
A sala é a pasta do projeto em que o agente está trabalhando; a conversa sai do escritório uma hora depois do último
passo.

## Como usar

**Câmera:** arraste para mover, role para dar zoom, clique duplo num personagem para segui-lo.

**Atalhos:**

| Tecla      | Ação                                   |
| ---------- | -------------------------------------- |
| `T`        | terminal do agente selecionado         |
| `P`        | próximo pedido (aprovação ou pergunta) |
| `M`        | meu dia                                |
| `L`        | timelapse do dia                       |
| `F`        | seguir o agente selecionado            |
| `/`        | buscar                                 |
| `O` ou `0` | visão geral                            |
| `[` e `]`  | painel lateral e feed                  |
| `Esc`      | limpar a seleção                       |
| `?`        | ajuda completa                         |

**Modo demonstração:** acrescente `?mock=1` ao endereço (ex.: http://localhost:4747/?mock=1) para ver o escritório
cheio de agentes simulados, sem precisar de nenhuma sessão aberta.

## Configuração

Tudo é opcional. Defina as variáveis no ambiente antes de subir o Karasudo.

| Variável                   | Padrão                  | O que faz                                                                                |
| -------------------------- | ----------------------- | ---------------------------------------------------------------------------------------- |
| `KARASUDO_PORT`            | `4747`                  | Porta do servidor.                                                                       |
| `KARASUDO_UPDATE_CHECK`    | ligado                  | `0` desliga a consulta de versão nova no GitHub.                                         |
| `KARASUDO_CODEX`           | ligado                  | `0` deixa o Codex de fora.                                                               |
| `KARASUDO_GEMINI`          | ligado                  | `0` deixa o Gemini CLI de fora.                                                          |
| `KARASUDO_ANTIGRAVITY`     | ligado                  | `0` deixa o Antigravity de fora.                                                         |
| `KARASUDO_CLAUDE_DIRS`     | detecção automática     | Pastas das contas do Claude Code, separadas por vírgula.                                 |
| `KARASUDO_CODEX_DIRS`      | detecção automática     | Pastas do Codex, separadas por vírgula.                                                  |
| `KARASUDO_GEMINI_DIRS`     | `~/.gemini`             | Pastas do Gemini CLI, separadas por vírgula.                                             |
| `KARASUDO_ANTIGRAVITY_DIR` | `~/.gemini/antigravity` | Pasta do Antigravity.                                                                    |
| `KARASUDO_PTY`             | desligado               | `1` liga o terminal interativo (assumir e abrir sessões do Claude Code pelo escritório). |

## Desenvolvimento

| Comando                       | O que faz                                                                          |
| ----------------------------- | ---------------------------------------------------------------------------------- |
| `npm run dev`                 | Servidor e página com recarga automática.                                          |
| `npm test`                    | Testes (Vitest).                                                                   |
| `npm run typecheck`           | Checagem de tipos.                                                                 |
| `npm run i18n:check`          | Textos sem tradução (a interface existe em português, inglês, espanhol e francês). |
| `npm run build` / `npm start` | Compila e roda a versão de produção.                                               |

Organização do código:

- `server/`: servidor Node, sem dependências de runtime. Cada ferramenta tem a sua fonte em `server/sources/`
  (`codex/`, `gemini/`, `antigravity/`; a do Claude Code fica na raiz da pasta).
- `client/`: a página (o prédio, os personagens e os painéis).
- `shared/`: tipos e textos usados pelos dois lados; as traduções ficam em `shared/locales/`.
- `mod/`: o mod do Claude Code e os hooks do Codex e do Gemini CLI.
- `scripts/`: instaladores e o gerador da pixel art da marca (`scripts/assets/pixelart.py`).

Os dados do Karasudo (nomes dos personagens, estatísticas do dia, linha do tempo) ficam em `~/.karasudo`.

Todo texto visível passa por `tr('texto em português')`, com a tradução em `shared/locales/`. Toda mudança visível
entra em "Não lançado" no [`CHANGELOG.md`](CHANGELOG.md).

## Problemas comuns

**O agente não aparece.** A sessão precisa estar aberta e com pelo menos uma mensagem enviada. No Antigravity, a
conversa precisa ter escrito alguma coisa na última hora. Confira em `http://localhost:4747/api/health` se a pasta da
ferramenta aparece em `sources`.

**Aparece com atraso.** Instale o mod (Claude Code) ou os hooks (Codex e Gemini CLI). Veja
[Conectar cada ferramenta](#conectar-cada-ferramenta).

**"A porta já está em uso".** Outro programa (ou outro Karasudo) está na porta. Feche-o ou use outra porta com
`KARASUDO_PORT`.

**O ícone antigo continua na aba do navegador.** O navegador guarda favicons por um tempo: atualize com `Ctrl+F5`.

## Créditos e licença

O Karasudo é baseado no [Habblaud](https://github.com/marmottajr/habblaud), de Márcio Junior, distribuído sob a
licença MIT. Veja o arquivo [`LICENSE`](LICENSE).
